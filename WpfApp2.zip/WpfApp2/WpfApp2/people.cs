﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
   public class people
    {
       public int ID { get; set; }

       public string FisrtName { get; set; }

      public  string Surname { get; set; }
       public DateTime birthday { get; set; }
       public double rise { get; set; }
       public double weight { get; set; }

    }
}
