﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
     

        public MainWindow()
        {
            InitializeComponent();
        }
        DateBaseContexst dataContext = new DateBaseContexst();

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string[] nameRandom =

            {
           "Максим",
            "Антон",
             "Юра",
             "Гена",
             "Виктор",
             "Андрей",
             "Алексей",
             "Денис",
             "Игорь"
             };

            string[] SurnameRandom =

            {
                "Иванов",
          "Петров",
            "Сидоров",
            "Глушков",
            "Капотов",
             "Астанкеев",
             "Васильев",
            "Евсеев",
             "Шилоносов"
             };
            List<people> people = new List<people>();
            Random rand = new Random();
            for (int i = 0; i <= 5; i++)
            {
                people p = new people()

                {
                    FisrtName = nameRandom[rand.Next(nameRandom.Length)],
                    Surname = SurnameRandom[rand.Next(SurnameRandom.Length)],
                    birthday = new DateTime(rand.Next(1990, 2005), rand.Next(1, 12), rand.Next(1, 31)),
                    rise = rand.NextDouble() * rand.Next(100, 190),
                    weight = rand.NextDouble() * rand.Next(50, 100)


                };

                people.Add(p);


            }
            lvGeneratePeople.ItemsSource = people;
            dataContext.peoples.AddRange (people);
            dataContext.SaveChanges();
        }

        private void lvGeneratePeople_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderByDescending(weigth => weigth.weight).ToList();
            tbCountPeople.Text =$"Количество людей в базе данных:{ dataContext.peoples.Count().ToString()}";
            string nameW = $"Имя - { dataContext.peoples.Max(p => p.weight)}. вес - { dataContext.peoples.Max(p =>p.weight)}";
            double sumW = dataContext.peoples.Sum(p => p.weight);
           MessageBox.Show(sumW.ToString());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            lvSorting.ItemsSource = dataContext.peoples.OrderByDescending(rise => rise.rise).ToList();
            tbCountPeople.Text = $"Количество людей в базе данных:{ dataContext.peoples.Count().ToString()}";
            string nameW = $"Имя - { dataContext.peoples.Max(p => p.rise)}. рост - { dataContext.peoples.Max(p => p.rise)}";
            double sumW = dataContext.peoples.Sum(p => p.rise);
            MessageBox.Show(sumW.ToString());

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.OrderByDescending(birthday => birthday.birthday).ToList();
            tbCountPeople.Text = $"Количество людей в базе данных:{ dataContext.peoples.Count().ToString()}";
            string nameW = $"Имя - { dataContext.peoples.Max(p => p.birthday)}.Дата Рождения - { dataContext.peoples.Max(p => p.birthday)}";
            
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.GroupBy(FisrtName => FisrtName.FisrtName).ToList();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            lvSorting.ItemsSource = dataContext.peoples.GroupBy(Surname => Surname.Surname).ToList();
        }
    }
}
